const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "", // Name of command
    type: 2, // Command type
    run: async (client, interaction, config, db) => {
        // execute

    },
};