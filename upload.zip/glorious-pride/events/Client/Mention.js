const {
	EmbedBuilder
} = require('discord.js');
const client = require("../../index");
const config = require("../../config/config.js");
const { QuickDB } = require("quick.db");
const db = new QuickDB();
const ms = require('ms');

module.exports = {
	name: 'messageCreate'
};

	client.on('messageCreate', async (message) => {
		// In case the author is a bot
		if (message.author.bot) return;

		// In case the user tries to dm the bot
		if (!message.guild || !message.guild.available) {
			return message.reply(`Hi ${message.author.username}!`);
		}
		const mentionRegex = RegExp(`^<@!?${client.user.id}>$`);
		if (message.content.match(mentionRegex)) {
      const prefix = await db.get(`guild_prefix_${message.guild.id}`) || config.Prefix || "?";
			const e = new EmbedBuilder()
      .setDescription(`** Hai ${message.author}**\n> GLORIOUS PRIDE Adalah\n> Bot Official Server Glorious Area.\n> Di buat pada tanggal 17-03-2023.\n> Yang Berfungsi untuk membantu perkembangan server GLORIOUS AREA.\n *Silahkan Gunakan \`${prefix}help\` untuk bantuan lebih lanjut*`)
      .setColor("Random")

    message.reply({ embeds: [e], ephemeral: true })
				.then((msg) => {
					setTimeout(() => {
						msg.delete().catch((err) => {
							if (err.code !== 10008) return console.log(err);
						});
					}, ms('10m'));
				});
    }
	});