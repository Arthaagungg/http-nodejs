const { EmbedBuilder } = require("discord.js");
const moment = require('moment-timezone');
const client = require("../../index");
const schema = require("../../database/welcomeChannel");


module.exports = {
  name: "guildMemberAdd"
};

client.on('guildMemberAdd', async (member) => {
  const GetChannel = await schema.findOne({ Guild: member.guild.id });
  if (!GetChannel) return;
  const channel = member.guild.channels.cache.find((ch) => ch.id === GetChannel.Channel);
  if (!channel) return;

const joinDate = moment.tz(member.joinedAt, 'Asia/Jakarta').format('MMMM Do YYYY, h:mm:ss a');

  // Get user's account creation date
  const createDate = moment(member.user.createdAt).format('MMMM Do YYYY, h:mm:ss a');

  // Get user's account age
  const accountAge = moment.duration(moment().diff(moment(member.user.createdAt))).asDays();
    channel.send({ embeds: [
  new EmbedBuilder()
.setColor("Green")
.setTitle(`Welcome to the server, ${member.displayName}!`)
.setDescription(`*Keep Enjoy.*`)
.setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
	.addFields(
		{ name: '◎ Nickname :', value: `➥ ${member.user.tag}`, inline: true },
		{ name: '◎ Join Date :', value: `➥ ${joinDate}`, inline: true },
		{ name: '◎ Account Creation Date :', value: `➥ ${createDate}`, inline: true },
    { name: '◎ Account Age :', value: `➥ ${accountAge.toFixed(0)} days`, inline: true },
	)
.setImage('https://media.discordapp.net/attachments/1074118404795027569/1086611691531419688/20211102_181818.gif')
.setTimestamp()
.setFooter({text: `You are member #${member.guild.memberCount} `})
    ] });
});

