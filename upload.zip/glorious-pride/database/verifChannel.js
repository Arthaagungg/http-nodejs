const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    Guild: String,
    Channel: String,
    Role: String,
    Voice: String,

});

module.exports = mongoose.model("verifChannels", Schema);