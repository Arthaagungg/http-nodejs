module.exports = {

  Prefix: "glo.", // YOUR BOT PREFIX.

  Users: {
    OWNERS: ["781943114487037963"] // THE BOT OWNERS ID.
  },

  Handlers: {
    MONGO: "" // YOUR MONGO URI. (USE THIS ONLY IN VSCODE)
  },

  Client: {
    TOKEN: "", // YOUR BOT TOKEN. (USE THIS ONLY IN VSCODE)
    ID: "1084262507453100072" // YOUR BOT ID.
  }

}
