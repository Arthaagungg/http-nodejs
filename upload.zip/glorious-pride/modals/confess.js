const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageEmbed, } = require('discord.js');
const schema = require("../database/logsconfessChannel");

module.exports = {
    id: "confess-modals",
    run: async (client, interaction, config, db) => {
      
  let Confess = interaction.fields.getTextInputValue("inputConfess");

      await interaction.channel.send({
        embeds: [
          new EmbedBuilder()
            .setTitle(`Confessions Server  ${interaction.guild.name} `)
          .setDescription(`<:anon:1086708922020278292> \`Anonymous Confessions :\` \n> ${Confess} \n`)
            .setColor('Random')
            .setFooter({ text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp(new Date())
        ],
        components: [
          new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('confess')
                .setLabel('Confessions')
                .setStyle(ButtonStyle.Secondary).setEmoji(`<:confess:1086715645732847656> `),
              new ButtonBuilder()
                .setCustomId('confessReply')
                .setLabel('Reply')
.setStyle(ButtonStyle.Secondary).setEmoji(`<:reply:1086715569518149845> `)
            )
        ],
      });

  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Mengirim Confessions, **TERIMAKASIH**.")
                    .setColor('Green')
            ],
            ephemeral: true
        })

    const user = interaction.user;
    const userTag = `${user.username}#${user.discriminator}`;

    const data = await schema.findOne({ Guild: interaction.guild.id });
      
const channel = client.channels.cache.get(data.Channel);
      await channel.send(`> User : ${userTag}\n> User-Id : ${user.id}\n> Confess : ${Confess}`);



    },
};
