const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageEmbed, } = require('discord.js');
const schema = require("../database/introChannel");

module.exports = {
    id: "intro-modals",
    run: async (client, interaction, config, db) => {
  let Nama = interaction.fields.getTextInputValue("inputNama");
  let Umur = interaction.fields.getTextInputValue("inputUmur");
  let Gender = interaction.fields.getTextInputValue("inputGender");
  let Kota = interaction.fields.getTextInputValue("inputKota");
  let Hobi = interaction.fields.getTextInputValue("inputHobi");

const user = interaction.user;
const discordLink = `https://discord.com/users/${user.id}`;
const username = user.username;

await interaction.channel.send({
            embeds: [
    new EmbedBuilder()
    .setTitle(`Intro Member Server  ${interaction.guild.name}`)
    .setDescription(`Profile : [${username}](${discordLink}) \n> ➥ **Nama    : ${Nama}** \n> ➥ **Umur    : ${Umur}** \n> ➥ **Gender : ${Gender}** \n> ➥ **Kota      : ${Kota}** \n> ➥ **Hobi      : ${Hobi}**`)
    .setColor('Blue')
    .setImage('https://cdn.discordapp.com/attachments/891377121551859723/1061540015513022464/ezgif-3-78960eeb9b.gif')
.setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .setFooter({text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
             .setTimestamp(new Date()) ],
     components: [
       new ActionRowBuilder()
      .addComponents(
       new ButtonBuilder()
     .setCustomId('intro')
    .setLabel('Form Intro')  
.setStyle(ButtonStyle.Secondary).setEmoji(`<:whitelist:1074366201083469846> `)
  )
     ],
   });
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses membuat Introduction.")
                    .setColor('Green')
            ],
            ephemeral: true
        })

    },
};