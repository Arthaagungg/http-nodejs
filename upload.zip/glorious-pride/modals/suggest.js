const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageEmbed, } = require('discord.js');
const schema = require("../database/suggestChannel");

module.exports = {
    id: "suggest-modals",
    run: async (client, interaction, config, db) => {
    const user = interaction.user;
    const userTag = `${user.username}#${user.discriminator}`;
      
  let Suggest = interaction.fields.getTextInputValue("inputSuggest");

  await interaction.
channel.send({
            embeds: [
    new EmbedBuilder()
    .setTitle(`Suggest For ${interaction.guild.name} <a:gl_lightred:891028337848369162> `)
    .setDescription(`> **From : ${userTag}**\n**__Suggest :__**\n <a:gl_tanya:913726039103012885> ${Suggest}`)
    .setColor('Green')
.setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .setFooter({text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
             .setTimestamp(new Date())
              ],
     components: [
       new ActionRowBuilder()
      .addComponents(
       new ButtonBuilder()
     .setCustomId('suggest')
.setStyle(ButtonStyle.Secondary)
.setLabel('Isi Suggest')  .setEmoji(`<:rename:1074366133089603695>`)
  )
     ],
    }).then(async (message) => {
await message.react('👍');
await message.react('👎');
})
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Mengirim Suggest, **TERIMAKASIH**.")
                    .setColor('Green')
            ],
            ephemeral: true
        })
    },
};
