const { EmbedBuilder } = require("discord.js");

module.exports = {
    id: "autodc-modals",
    run: async (client, interaction, config, db) => {
  const { guild, member } = interaction;
const Embed = new EmbedBuilder().setColor("Green");
                let Time = interaction.fields.getTextInputValue("inputTime");
                let Satuan = interaction.fields.getTextInputValue("inputSatuan");
                let AutoDc = 0;
                if (Satuan === "jam" || Satuan === "Jam" || Satuan === "h" || Satuan === "H" || Satuan === "Hour" || Satuan === "hour") {
                    AutoDc = Time * 60000 * 60;
                } else if (Satuan === "menit" || Satuan === "Menit" || Satuan === "min" || Satuan === "Min" || Satuan === "Minute" || Satuan === "minute") {
                    AutoDc = Time * 60000;
                } else {
                    await interaction.reply({ embeds: [Embed.setDescription(`⚠️ Format Tidak Sesuai. \n Contoh Format Yang benar :\n ⚫ 30 menit \n ⚫ 1 jam`).setColor("Red")], ephemeral: true });
                }
                      if (AutoDc) {
                    await interaction.reply({ embeds: [Embed.setDescription(`✔️ | Berhasil Setting Auto Disconnect Dengan Waktu **${Time} ${Satuan}**.`).setColor("Green")], ephemeral: true });
                    setTimeout(() => {
  if (member.voice.channel) {
                    member.voice.setChannel(null);
                        }
                    }, AutoDc);
                      }
    },
};
