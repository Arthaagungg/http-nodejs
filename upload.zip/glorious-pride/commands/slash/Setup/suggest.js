const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const schema = require("../../../database/suggestChannel");
module.exports = {
    name: "suggest",
    description: "Setup Suggest",
    type: 1,
    options: [{name: 'channel', type: 7, description: 'Channel Suggest', required: true}],
    permissions: {
        DEFAULT_PERMISSIONS: "",
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
    const user = interaction.user;
    const userTag = `${user.username}#${user.discriminator}`;


    const channel = interaction.options.getChannel('channel');
  if (channel){

    schema.findOne({ Guild: interaction.guild.id }, async (err, data) => {
      if(data){
 const channelSuggest = await schema.findOneAndUpdate({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }else{
  const channelSuggest = await schema.create({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }
    });
    
   await channel.send({
            embeds: [
    new EmbedBuilder()
    .setTitle(`Suggest For ${interaction.guild.name} <a:gl_lightred:891028337848369162> `)
    .setDescription(`> **From : ${userTag}**\n**__Suggest :__**\n <a:gl_tanya:913726039103012885> Silahkan Klik Button Di Bawah Untuk Suggest !`)
    .setColor('Green')
.setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .setFooter({text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
             .setTimestamp(new Date())
              ],
     components: [
       new ActionRowBuilder()
      .addComponents(
       new ButtonBuilder()
     .setCustomId('suggest')
.setStyle(ButtonStyle.Secondary).setEmoji(`<:rename:1074366133089603695>`)
  )
     ],
   });
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Setup Suggest.")
                    .setColor('Green')
            ],
            ephemeral: true
        })
    
  }

    },
};