const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const schema = require("../../../database/welcomeChannel");
module.exports = {
    name: "welcome",
    description: "Setup Welcome Message",
    type: 1,
    options: [{name: 'channel', type: 7, description: 'Channel Welcome Message', required: true}],
    permissions: {
        DEFAULT_PERMISSIONS: "",
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
    const channel = interaction.options.getChannel('channel');
  if (channel){

    schema.findOne({ Guild: interaction.guild.id }, async (err, data) => {
      if(data){
 const channelSuggest = await schema.findOneAndUpdate({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }else{
  const channelSuggest = await schema.create({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }
    });
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Setup Welcome Message.")
                    .setColor('Green')
            ],
            ephemeral: true
        })
    
  }

    },
};