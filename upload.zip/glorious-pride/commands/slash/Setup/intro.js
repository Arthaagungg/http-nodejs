const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const schema = require("../../../database/introChannel");
module.exports = {
    name: "intro",
    description: "Setup introduction",
    type: 1,
    options: [{name: 'channel', type: 7, description: 'Channel Intro', required: true}],
    permissions: {
        DEFAULT_PERMISSIONS: "",
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
      
const user = interaction.user;
const discordLink = `https://discord.com/users/${user.id}`;
const username = user.username;
      

    const channel = interaction.options.getChannel('channel');
  if (channel){

    schema.findOne({ Guild: interaction.guild.id }, async (err, data) => {
      if(data){
 const channelSuggest = await schema.findOneAndUpdate({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }else{
  const channelSuggest = await schema.create({
Guild: interaction.guild.id,
Channel: channel.id,
 });
      }
    });
    
   await channel.send({
            embeds: [
    new EmbedBuilder()
    .setTitle(`Intro Member Server  ${interaction.guild.name}`)
    .setDescription(`Profile : [${username}](${discordLink}) \n> ➥ **Nama    : Nickname** \n> ➥ **Umur    : 17+** \n> ➥ **Gender : Laki/Perempuan** \n> ➥ **Kota      : Bogor** \n> ➥ **Hobi      : Dengerin Film**`)
    .setColor('Blue')
    .setImage('https://cdn.discordapp.com/attachments/891377121551859723/1061540015513022464/ezgif-3-78960eeb9b.gif')
.setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .setFooter({text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
             .setTimestamp(new Date())
              ],
     components: [
       new ActionRowBuilder()
      .addComponents(
       new ButtonBuilder()
     .setCustomId('intro')
    .setLabel('Form Intro')  
.setStyle(ButtonStyle.Secondary).setEmoji(`<:whitelist:1074366201083469846> `)
  )
     ],
   });
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Setup Introduction.")
                    .setColor('Green')
            ],
            ephemeral: true
        })
    
  }

    },
};