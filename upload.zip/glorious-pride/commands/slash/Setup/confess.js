const { EmbedBuilder, PermissionFlagsBits, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const schema = require("../../../database/confessChannel");
const schema2 = require("../../../database/logsconfessChannel");
module.exports = {
  name: "confession",
  description: "Setup confessions",
  type: 1,
  options: [],
  permissions: {
    DEFAULT_PERMISSIONS: "",
    DEFAULT_MEMBER_PERMISSIONS: "Administrator"
  },
  run: async (client, interaction, config, db) => {

    const { guild } = interaction;
    const { ViewChannel,SendMessages } = PermissionFlagsBits;

    const everyoneRole = guild.roles.cache.find(role => role.name === '@everyone');

    const Category = await client.guilds.cache.get(guild.id).channels.create({
      name: `│───── CONFESSIONS`,
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.cache.get(everyoneRole.id), //everyone
          deny: [ViewChannel]
        },
      ]
    });

    const Confessions = await guild.channels.create({
      name: `・🕴️・Confessions`,
      type: ChannelType.GuildText,
      parent: Category,
    }).then(async (channel) => {
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setTitle(`Confessions Server  ${interaction.guild.name} `)
            .setDescription('<:anon:1086708922020278292> `Anonymous Confessions :`\n> turunkan harga bbm !\n')
            .setColor('Random')
            .setFooter({ text: `Copyright ©2023 - ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp(new Date())
        ],
        components: [
          new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('confess')
                .setLabel('Confessions')
                .setStyle(ButtonStyle.Secondary).setEmoji(`<:confess:1086715645732847656> `),
              new ButtonBuilder()
                .setCustomId('confessReply')
                .setLabel('Reply')
                .setStyle(ButtonStyle.Secondary).setEmoji(`<:reply:1086715569518149845> `)
            )
        ],
      })
      schema.findOne({ Guild: interaction.guild.id }, async (err, data) => {
        if (data) {
          await schema.findOneAndUpdate({
            Guild: channel.guild.id,
            Channel: channel.id,
          });
        } else {
          await schema.create({
            Guild: channel.guild.id,
            Channel: channel.id,
          });
        }
      });
    });

    const LogsConfessions = await guild.channels.create({
      name: `・❌・Logs Confessions`,
      type: ChannelType.GuildText,
      parent: Category,
    });


    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setDescription("✔️ | Sukses Setup Confessions.")
          .setColor('Green')
      ],
      ephemeral: true
    })

    if (LogsConfessions) {
      schema2.findOne({ Guild: interaction.guild.id }, async (err, data) => {
        if (data) {
          await schema2.findOneAndUpdate({
            Guild: interaction.guild.id,
            Channel: LogsConfessions.id,
          });
        } else {
          await schema2.create({
            Guild: interaction.guild.id,
            Channel: LogsConfessions.id,
          });
        }
      });
    }

  },
};