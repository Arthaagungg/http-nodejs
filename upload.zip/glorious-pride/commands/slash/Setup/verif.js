const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const schema = require("../../../database/verifChannel");
module.exports = {
    name: "verif",
    description: "Setup Welcome Message",
    type: 1,
    options: [{name: 'channel', type: 7, description: 'Channel verif ladies', required: true},{name: 'role', type: 8, description: 'Role Admin verif ladies', required: true},
{name: 'voice', type: 3, description: 'link voice verif ladies', required: true},],
    permissions: {
        DEFAULT_PERMISSIONS: "",
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
    const channel = interaction.options.getChannel('channel');
      const role = interaction.options.getRole('role');
      const voice = interaction.options.getString("voice");
  if (channel){
    schema.findOne({ Guild: interaction.guild.id }, async (err, data) => {
      if(data){
 const channelSuggest = await schema.findOneAndUpdate({
Guild: interaction.guild.id,
Channel: channel.id,
Role: role.id,
Voice: voice,

 });
      }else{
  const channelSuggest = await schema.create({
Guild: interaction.guild.id,
Channel: channel.id,
Role: role.id,
Voice: voice,
 });
      }
    });
    
  await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("✔️ | Sukses Setup Verif ladies")
                    .setColor('Green')
            ],
            ephemeral: true
        })
    
  }

    },
};