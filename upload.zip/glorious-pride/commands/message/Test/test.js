const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "test",
    type: 3,
    run: async (client, interaction, config, db) => {
      await interaction.reply("test");
    },
};
