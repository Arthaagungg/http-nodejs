const { EmbedBuilder, ButtonBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    config: {
        name: "dc", // Name of Command
        description: "Automatis Disconnect Room Voice", // Command Description
        usage: "dc [Reactions Emoji]" // Command usage
    },
    permissions: ['SendMessages'], // User permissions needed
    owner: false, // Owner only?
    run: async (client, message, args, prefix, config, db) => {
      const member = message.member;
    if(!member.voice.channel) return message.reply("Anda sedang tidak berada di dalam voice.").then((m) => {
      setTimeout(() => {
  m.delete();
}, 5000);
    });

const embed = new EmbedBuilder()
                .setTitle(`Auto Disconnect Voice - ${message.guild.name} Server !`)
                .setDescription(`Silahkan Reactions emoji di bawah untuk mengatur waktu Auto Disconnect.\n*Note:*\n- 30 Menit/min/minute\n- 1 Jam/h/hour `)
                .setColor("Green")
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `Copyright ©2023 - ${message.guild.name}`, iconURL: message.guild.iconURL() })
                .setTimestamp();

const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('autoDc').setStyle(ButtonStyle.Secondary).setEmoji(`<:timer:1086072699379535993> `)
  );

    message.channel.send({
                embeds: ([embed]),
                components: [
                    button
                ]
            }).then((e) => {
      setTimeout(() => {
  e.delete();
  message.delete();
}, 100000);
    });

    },
};