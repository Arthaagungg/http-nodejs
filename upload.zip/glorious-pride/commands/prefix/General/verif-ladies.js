const { EmbedBuilder } = require("discord.js");
const schema = require("../../../database/verifChannel");

module.exports = {
  config: {
    name: "verif",
    description: "Announcement Staff For Verifikasi Ladies",
    usage: "verif [In Channel Verif Ladies]"
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix) => {
    const data = await schema.findOne({ Guild: message.guild.id });
    if (!data) return
    if (data.Channel !== message.channel.id) return;
    await message.channel.send(
      {content: `Verif Ladies Announcement <@&${data.Role}>
 ada yang mau verif role ladies , tolong di bantu 🙏\n> || Voice : ${data.Voice} ||`,
        embeds: [
          new EmbedBuilder()
            .setAuthor(
              {
                name: `Verifikasi Ladies - ${message.guild.name}`,
                iconURL: client.user.displayAvatarURL(
                  {
                    dynamic: true
                  }
                )
              }
            )
.setThumbnail(message.member.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`Hallo Kak <@${message.member.user.id}> \n> Silahkan masuk ke voice channel Verifikasi Ladies, Untuk verifikasi. \n> Atau bisa klik link voice di bawah,\n> Dan tunggu Beberapa Menit\n> Sampai <@&${data.Role}> Kami Datang 🙏\n\n> Terimakasi Hormat Kami <@&${data.Role}>`)
.setFooter({text: `Copyright ©2023 - ${message.guild.name}`, iconURL: message.guild.iconURL() })
  .setTimestamp(new Date())
            .setColor('Blue')
        ]
      }
    );


  },
};
