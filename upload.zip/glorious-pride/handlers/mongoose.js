const config = require("../config/config.js");
const superDjs = require("super-djs");
const mongoose = require('mongoose');


module.exports = (client) => {
	console.log(superDjs.colourText('[DATABASE] Connecting to MongoDB...', 'yellow'));
	const mongo = process.env.MONGO || config.Handlers.MONGO;
	if (!mongo) {
		console.warn("[WARN] A Mongo URI/URL isn't provided! (Not required)");
	} else {
    
mongoose.set('strictQuery', false);
		superDjs.connectMongoDB(mongo, true, superDjs.colourText('[DATABASE] Connected to MongoDB!', 'green'));	
	};
};
